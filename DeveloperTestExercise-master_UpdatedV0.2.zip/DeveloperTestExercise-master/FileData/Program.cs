﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                //Get the inputs
                Console.WriteLine("Please provide the Arguments");
                Console.ReadLine();

                if (args != null && args.Length > 0)
                {

                    string operationType = args[0].ToString().ToUpper();
                    string filePath = args[1].ToString(); 

                    FileOperations fileOperationDetail = new FileOperations();

                    //Method to identify operation Type
                    string OperationsType=fileOperationDetail.OperationType(operationType);


                    if(OperationsType== "Version")
                    {
                        string strFileVersion = fileOperationDetail.FileVersion(operationType,filePath);
                        Console.WriteLine("File version is {0}", strFileVersion);
                    }
                    else if (OperationsType == "Size")
                    {
                        int strFileSize = fileOperationDetail.FileSize(operationType, filePath);
                        Console.WriteLine("File version is {0}", strFileSize.ToString());
                    }
                    else
                    {
                        Console.WriteLine("Please Provide valid arguments");
                    }
                }
                else
                    Console.WriteLine("No Arguments provided, Please Provide Arguments");

                Console.ReadLine();
            }
            catch
            {
                Console.WriteLine("OOPS Something went wrong!!!");
                Console.Read();
            }

        }
    }
       
    
}
