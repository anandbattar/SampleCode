﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                //Get the inputs
                Console.WriteLine("Please provide the Arguments");
                Console.ReadLine();

                FileDetails fileDetail = new FileDetails();

                if (args != null && args.Length > 0)
                {

                    string operationType = args[0].ToString().ToUpper();
                    string filePath = args[1].ToString(); // TODO: Validate if file path is valid and can be accessed.


                    if (operationType.Contains("-V") || operationType.Contains("/V"))
                    {
                        string strFileVersion = fileDetail.Version(args[1].ToString());
                        Console.WriteLine("File version is {0}", strFileVersion);
                    }
                    else if (operationType.Contains("-S") || operationType.Contains("/S"))
                    {
                        int strFileSize = fileDetail.Size(args[1].ToString());
                        Console.WriteLine("File version is {0}", strFileSize.ToString());
                    }
                    else
                    {
                        Console.WriteLine("Please Provide valid arguments");
                    }
                }
                else
                    Console.WriteLine("No Arguments provided, Please Provide Arguments");

                Console.ReadLine();
            }
            catch
            {
                Console.WriteLine("OOPS Something went wrong!!!");
                Console.Read();
            }

        }
    }
}
