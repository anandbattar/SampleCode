﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FileData;

namespace FileDataTest
{
    [TestClass]
    public class UnitTest1
    {

        string[] fileOperationType = { "-V", "--V", "/V", "--VERSION" };
        string[] fileOperationSize = { "-S", "--S", "/S", "--SIZE" };

        string[] fileOperationErrorType = { "-X", "--Y", "/Z", "--DIVERSION" };
        string[] fileOperationErrorSize = { "-A", "--B", "/C", "--RESIZE" };

        #region "Positive test cases"

        [TestMethod]
        public void Test_FileVersion()
        {
            FileOperations fileOp = new FileOperations();

            foreach (string type in fileOperationType)
            {
                string OperationsType = fileOp.OperationType(type);

                if (OperationsType == "Version")
                {
                    string fileVersion = fileOp.FileVersion(type, "C:\test.txt");
                    Assert.AreNotEqual(string.Empty, fileVersion);
                }
                else
                    Assert.Fail();
            }

        }

        [TestMethod]
        public void Test_FileSize()
        {
            FileOperations fileOp = new FileOperations();

            foreach (string size in fileOperationSize)
            {
                string OperationsType = fileOp.OperationType(size);

                if (OperationsType == "Size")
                {
                    int fileVersion = fileOp.FileSize(size, "C:\test.txt");
                    Assert.AreNotEqual(string.Empty, fileVersion);
                }
                else
                    Assert.Fail();
            }
        }
        #endregion

        #region "Negative test cases"

        [TestMethod]
        public void Test_FileVersionError()
        {
            FileOperations fileOp = new FileOperations();

            foreach (string type in fileOperationErrorType)
            {
                string OperationsType = fileOp.OperationType(type);

                if (OperationsType == "Version")
                {
                    string fileVersion = fileOp.FileVersion(type, "C:\test.txt");
                    Assert.AreNotEqual(string.Empty, fileVersion);
                }
                else
                    Assert.AreEqual(string.Empty, OperationsType);
            }

        }

        [TestMethod]
        public void Test_FileSizeError()
        {
            FileOperations fileOp = new FileOperations();

            foreach (string size in fileOperationErrorSize)
            {
                string OperationsType = fileOp.OperationType(size);

                if (OperationsType == "Size")
                {
                    int fileVersion = fileOp.FileSize(size, "C:\test.txt");
                    Assert.AreNotEqual(string.Empty, fileVersion);
                }
                else
                    Assert.AreEqual(string.Empty, OperationsType);
            }
        }
        #endregion
    }
}
