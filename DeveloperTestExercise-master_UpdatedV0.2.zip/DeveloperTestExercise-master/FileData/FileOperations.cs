﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdPartyTools;

namespace FileData
{
    public class FileOperations
    {
        FileDetails fileDetail = new FileDetails();

        /// <summary>
        /// Method to determine Operation Type
        /// </summary>
        /// <param name="operationTypeValue"></param>
        /// <returns></returns>
        public string OperationType(string operationTypeValue)
        {
            try
            {
                string[] fileOperationType = { "-V", "--V", "/V", "--VERSION" };
                string[] fileOperationSize = { "-S", "--S", "/S", "--SIZE" };

                foreach (string type in fileOperationType)
                {
                    if (operationTypeValue.Contains(type))
                    {
                        return "Version";
                    }
                }

                foreach (string size in fileOperationSize)
                {
                    if (operationTypeValue.Contains(size))
                    {
                        return "Size";
                    }
                }

                return string.Empty;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public string FileVersion(string operationType, string filePath)
        {
            try
            {
                if (operationType.Contains("-V") || operationType.Contains("/V"))
                {
                    if (ValidFile(filePath))
                    {
                        string strFileVersion = fileDetail.Version(filePath);
                        return strFileVersion;
                    }
                    else
                        return string.Empty;
                }
                else
                    return String.Empty;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int FileSize(string operationType, string filePath)
        {
            try
            {
                if (ValidFile(filePath))
                {
                    int strFileSize = fileDetail.Size(filePath);
                    return strFileSize;
                }
                else
                    return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Implementation skipped as it is out of scope for this task
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        private bool ValidFile(string filePath)
        {
            return true;
        }
    }
}
